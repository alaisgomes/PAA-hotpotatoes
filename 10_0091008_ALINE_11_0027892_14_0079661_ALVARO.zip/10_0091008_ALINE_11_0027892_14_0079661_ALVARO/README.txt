﻿Universidade de Brasília 
Projeto e Análise de Algoritmos 2/2016

Grupo:
10/0091008 - Aline Laís Tavares
14/0079661 - Alvaro Torres Vieira

11/0027892 - Diego santos Kieckbush 	


Participação:
Aline:  30 Questões referentes a um algoritmo de grafo, Dijkstra. (Parte 2)

Álvaro: 30 Questões referentes a Graham's Scan  (Parte 3)
Diego:  30 Questões referentes a Multiplicação em cadeia de matriz (parte 1)
